import os
from dotenv import load_dotenv

load_dotenv()

# --- Обязательные переменные (задаются в .env, см. .env.example) ---
BOT_TOKEN = os.getenv("BOT_TOKEN")            # токен бота от @BotFather
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))    # твой Telegram user_id — куда слать черновики
CHANNEL_ID = os.getenv("CHANNEL_ID")          # @username канала или -100xxxxxxxxxx

# Необязательно: ключ Unsplash для поиска фото, если на странице новости
# не нашлось подходящей картинки (og:image). Если не задан — используется
# первая крупная картинка со страницы или плейсхолдер.
UNSPLASH_ACCESS_KEY = os.getenv("UNSPLASH_ACCESS_KEY", "")

# --- Список источников новостей (RSS-ленты) ---
# Добавь сюда RSS-ссылки своих 10 источников.
# Формат: ("Название источника", "URL RSS-ленты")
FEEDS = [
    # ("Sport.ru", "https://sport.ru/rss/football.xml"),
    # ("Championat", "https://www.championat.com/rss/news/football/"),
    # ... добавь остальные сюда
]

# Как часто проверять ленты на новые новости (в минутах)
POLL_INTERVAL_MINUTES = 10

# Сколько последних записей из каждой ленты рассматривать за один проход
# (защита от обвала стартового большого списка при первом запуске)
MAX_ENTRIES_PER_FEED = 5

# Путь к файлу базы данных (SQLite) — хранит "уже обработанные" новости и черновики
DB_PATH = "bot_storage.db"
