import re
import logging

import feedparser
import requests
from bs4 import BeautifulSoup

from config import UNSPLASH_ACCESS_KEY, MAX_ENTRIES_PER_FEED

logger = logging.getLogger(__name__)

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; FootballNewsBot/1.0; +https://example.com/bot)"
}

PLACEHOLDER_IMAGE = "https://images.unsplash.com/photo-1508098682722-e99c43a406b2"  # общее фото футбольного мяча


def clean_html(raw_html: str) -> str:
    """Убирает HTML-теги из текста RSS summary."""
    if not raw_html:
        return ""
    text = BeautifulSoup(raw_html, "html.parser").get_text(separator=" ")
    return re.sub(r"\s+", " ", text).strip()


def fetch_feed_entries(feed_url: str):
    """Возвращает список последних записей RSS-ленты."""
    parsed = feedparser.parse(feed_url)
    if parsed.bozo and not parsed.entries:
        logger.warning(f"Не удалось разобрать ленту {feed_url}: {parsed.bozo_exception}")
        return []
    return parsed.entries[:MAX_ENTRIES_PER_FEED]


def entry_unique_id(entry) -> str:
    return entry.get("id") or entry.get("guid") or entry.get("link")


def extract_image_from_rss_entry(entry) -> str | None:
    """Пытается достать картинку прямо из RSS-записи (enclosure/media)."""
    if "media_content" in entry and entry.media_content:
        url = entry.media_content[0].get("url")
        if url:
            return url
    if "media_thumbnail" in entry and entry.media_thumbnail:
        url = entry.media_thumbnail[0].get("url")
        if url:
            return url
    for link in entry.get("links", []):
        if link.get("type", "").startswith("image/"):
            return link.get("href")
    return None


def extract_image_from_article(article_url: str) -> str | None:
    """Заходит на страницу статьи и ищет og:image / twitter:image / первую крупную картинку."""
    try:
        resp = requests.get(article_url, headers=HEADERS, timeout=10)
        resp.raise_for_status()
    except requests.RequestException as e:
        logger.warning(f"Не удалось загрузить страницу {article_url}: {e}")
        return None

    soup = BeautifulSoup(resp.text, "html.parser")

    og_image = soup.find("meta", property="og:image")
    if og_image and og_image.get("content"):
        return og_image["content"]

    twitter_image = soup.find("meta", attrs={"name": "twitter:image"})
    if twitter_image and twitter_image.get("content"):
        return twitter_image["content"]

    # fallback: первая достаточно большая картинка в теле статьи
    for img in soup.find_all("img"):
        src = img.get("src") or img.get("data-src")
        if src and src.startswith("http"):
            return src

    return None


def search_fallback_image(query: str) -> str:
    """Если у статьи вообще нет картинки — ищем через Unsplash (если задан ключ) либо возвращаем плейсхолдер."""
    if not UNSPLASH_ACCESS_KEY:
        return PLACEHOLDER_IMAGE
    try:
        resp = requests.get(
            "https://api.unsplash.com/search/photos",
            params={"query": query, "per_page": 1, "orientation": "landscape"},
            headers={"Authorization": f"Client-ID {UNSPLASH_ACCESS_KEY}"},
            timeout=10,
        )
        resp.raise_for_status()
        results = resp.json().get("results", [])
        if results:
            return results[0]["urls"]["regular"]
    except requests.RequestException as e:
        logger.warning(f"Unsplash fallback не сработал: {e}")
    return PLACEHOLDER_IMAGE


def get_image_for_entry(entry, article_url: str, title: str) -> str:
    """Порядок: картинка из RSS -> og:image статьи -> поиск по теме -> плейсхолдер."""
    image = extract_image_from_rss_entry(entry)
    if image:
        return image

    image = extract_image_from_article(article_url)
    if image:
        return image

    return search_fallback_image(title)


def build_draft_text(entry) -> str:
    title = entry.get("title", "").strip()
    summary = clean_html(entry.get("summary", ""))
    return f"⚽ {title}\n\n{summary}"
