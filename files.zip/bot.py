import asyncio
import logging

from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    FSInputFile,
)
from apscheduler.schedulers.asyncio import AsyncIOScheduler

import config
import storage
from fetcher import (
    fetch_feed_entries,
    entry_unique_id,
    get_image_for_entry,
    build_draft_text,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

bot = Bot(token=config.BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())


class EditDraft(StatesGroup):
    waiting_for_new_text = State()


def moderation_keyboard(draft_id: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(text="✅ Одобрить", callback_data=f"approve:{draft_id}"),
                InlineKeyboardButton(text="✏️ Редактировать", callback_data=f"edit:{draft_id}"),
                InlineKeyboardButton(text="❌ Отклонить", callback_data=f"reject:{draft_id}"),
            ]
        ]
    )


async def send_draft_to_admin(draft: dict):
    caption = draft["text"]
    if draft["source_link"]:
        caption += f"\n\n🔗 Источник: {draft['source_link']}"
    # Telegram ограничивает caption ~1024 символами
    if len(caption) > 1024:
        caption = caption[:1000].rsplit(" ", 1)[0] + "…"

    await bot.send_photo(
        chat_id=config.ADMIN_ID,
        photo=draft["image_url"],
        caption=caption,
        reply_markup=moderation_keyboard(draft["draft_id"]),
    )


async def poll_feeds():
    """Периодическая задача: проверяет все RSS-ленты и создаёт черновики для новых новостей."""
    if not config.FEEDS:
        logger.warning("Список FEEDS пуст — добавь RSS-ссылки в config.py")
        return

    for feed_name, feed_url in config.FEEDS:
        entries = fetch_feed_entries(feed_url)
        for entry in entries:
            eid = entry_unique_id(entry)
            if not eid or storage.is_entry_seen(eid):
                continue

            article_url = entry.get("link", "")
            title = entry.get("title", "Без названия")
            text = build_draft_text(entry)
            image_url = get_image_for_entry(entry, article_url, title)

            draft_id = storage.create_draft(
                feed_name=feed_name,
                source_link=article_url,
                title=title,
                text=text,
                image_url=image_url,
            )
            storage.mark_entry_seen(eid, feed_name)

            draft = storage.get_draft(draft_id)
            try:
                await send_draft_to_admin(draft)
            except Exception as e:
                logger.error(f"Не удалось отправить черновик админу: {e}")


@dp.message(Command("start"))
async def cmd_start(message: Message):
    await message.answer(
        "Привет! Я буду присылать сюда черновики футбольных новостей на модерацию.\n"
        "Команда /check — проверить ленты прямо сейчас."
    )


@dp.message(Command("check"))
async def cmd_check(message: Message):
    await message.answer("Проверяю ленты…")
    await poll_feeds()
    await message.answer("Готово. Если были новые новости — они уже отправлены выше.")


@dp.callback_query(F.data.startswith("approve:"))
async def handle_approve(callback: CallbackQuery):
    draft_id = callback.data.split(":", 1)[1]
    draft = storage.get_draft(draft_id)

    if not draft or draft["status"] != "pending":
        await callback.answer("Черновик уже обработан или не найден.", show_alert=True)
        return

    caption = draft["text"]
    if len(caption) > 1024:
        caption = caption[:1000].rsplit(" ", 1)[0] + "…"

    try:
        await bot.send_photo(
            chat_id=config.CHANNEL_ID,
            photo=draft["image_url"],
            caption=caption,
        )
        storage.update_draft_status(draft_id, "approved")
        await callback.message.edit_caption(
            caption=draft["text"] + "\n\n✅ ОПУБЛИКОВАНО В КАНАЛЕ",
            reply_markup=None,
        )
    except Exception as e:
        logger.error(f"Ошибка публикации в канал: {e}")
        await callback.answer(f"Ошибка публикации: {e}", show_alert=True)
        return

    await callback.answer("Опубликовано!")


@dp.callback_query(F.data.startswith("reject:"))
async def handle_reject(callback: CallbackQuery):
    draft_id = callback.data.split(":", 1)[1]
    draft = storage.get_draft(draft_id)

    if not draft or draft["status"] != "pending":
        await callback.answer("Черновик уже обработан или не найден.", show_alert=True)
        return

    storage.update_draft_status(draft_id, "rejected")
    await callback.message.edit_caption(
        caption=draft["text"] + "\n\n❌ ОТКЛОНЕНО",
        reply_markup=None,
    )
    await callback.answer("Отклонено.")


@dp.callback_query(F.data.startswith("edit:"))
async def handle_edit(callback: CallbackQuery, state: FSMContext):
    draft_id = callback.data.split(":", 1)[1]
    draft = storage.get_draft(draft_id)

    if not draft or draft["status"] != "pending":
        await callback.answer("Черновик уже обработан или не найден.", show_alert=True)
        return

    await state.set_state(EditDraft.waiting_for_new_text)
    await state.update_data(draft_id=draft_id)
    await callback.message.answer(
        "Пришли новый текст для этой новости одним сообщением.\n"
        "Он полностью заменит текущий текст."
    )
    await callback.answer()


@dp.message(EditDraft.waiting_for_new_text)
async def handle_new_text(message: Message, state: FSMContext):
    data = await state.get_data()
    draft_id = data.get("draft_id")
    draft = storage.get_draft(draft_id)

    if not draft or draft["status"] != "pending":
        await message.answer("Этот черновик уже нельзя редактировать.")
        await state.clear()
        return

    storage.update_draft_text(draft_id, message.text)
    await state.clear()

    updated = storage.get_draft(draft_id)
    await message.answer("Текст обновлён. Вот превью:")
    await send_draft_to_admin(updated)


async def main():
    storage.init_db()

    scheduler = AsyncIOScheduler()
    scheduler.add_job(poll_feeds, "interval", minutes=config.POLL_INTERVAL_MINUTES)
    scheduler.start()

    logger.info("Бот запущен.")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
